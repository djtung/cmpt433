"use strict";
// Client-side interactions with the browser.

// Make connection to server when web page is fully loaded.
// Adapted heavily from UDP_server example by Brian Fraser
var TIMEOUT_TIME = 2000

var socket = io.connect();
$(document).ready(function() {
	var bbgLastUpdateTime;
	var serverLastUpdateTime;

	$('#error-box').hide();

	window.setInterval(function() {
		sendBeagleboneCommand("8")
		sendServerCommand(1);
		if (Date.now() - serverLastUpdateTime > TIMEOUT_TIME) {
			$('#error-box').show();
			$('#error-text-1').html("Cannot contact server. (Is it running?)");
		} else if (Date.now() - bbgLastUpdateTime > TIMEOUT_TIME) {
			$('#error-box').show();
			$('#error-text-1').html("Cannot contact beatbox. (Is it running?)");
		} else {
			$('#error-box').hide();
		}
	}, 1000);

	$('#modeNone').click(function(){
		sendBeagleboneCommand("1");
	});
	$('#modeRock1').click(function(){
		sendBeagleboneCommand("2");
	});
	$('#modeRock2').click(function(){
		sendBeagleboneCommand("3");
	});
	$('#volumeDown').click(function(){
		sendBeagleboneCommand("4");
	});
	$('#volumeUp').click(function(){
		sendBeagleboneCommand("5");
	});
	$('#bpmDown').click(function(){
		sendBeagleboneCommand("6");
	});
	$('#bpmUp').click(function(){
		sendBeagleboneCommand("7");
	});
	
	socket.on('bbgreply', function(result) {
		bbgLastUpdateTime = Date.now();
		var res = result.split(" ");
		var mode = "None";
		if (res[0] == "0") {
			//
		} else if (res[0] == "1") {
			mode = "Rock #1";
		} else if (res[0] == "2") {
			mode = "Rock #2";
		}
		$('#modeid').html(mode);

		$('#volumeId').val(res[1]);
		$('#bpmId').val(res[2]);

		// from https://stackoverflow.com/questions/1322732/convert-seconds-to-hh-mm-ss-with-javascript
		var seconds = res[3]
		var date = new Date(null);
		date.setSeconds(seconds);
		var hmstime = date.toISOString().substr(11, 8);
		$('#status').html(hmstime + "(H:M:S)");
	});

	socket.on('serverreply', function(data) {
		serverLastUpdateTime = Date.now();
	});
	
});

function sendBeagleboneCommand(message) {
	socket.emit('bbgsend', message);
};

function sendServerCommand(message) {
	socket.emit('serversend', message);
};